<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Musik
 */

get_header();
?>
	<div class="archive-header">
		<h1 class="post-title" itemprop="headline"><?php esc_html_e( 'Page not found', 'musik' ); ?></h1>
		<?php get_search_form(); ?>
	</div>

</div>
<?php
get_sidebar();
get_footer();
