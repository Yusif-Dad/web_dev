wp.blocks.registerBlockStyle('core/gallery', {
	name: 'musik-hide-caption',
	label: wp.i18n.__('Hide captions', 'musik')
});
