<?php
/**
 * The sidebar containing the main widget areas.
 *
 * @package Musik
 */

if ( is_active_sidebar( 'sidebar-1' ) ) {
	?>
	<div id="sidebar" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		<h2 class="screen-reader-text"><?php esc_html_e( 'Sidebar', 'musik' ); ?></h2>
		<?php
		dynamic_sidebar( 'sidebar-1' );

		if ( get_theme_mod( 'musik_social_menu_position' ) === 'sidebar' ) {
			musik_social_menu();
		}
		?>
	</div>
	<?php
}
