=== Musik ===
Contributors: Poena
Requires at least: 4.7
Tested up to: 5.2
Requires PHP: 5.2
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Copyright: 2014-2019 Carolina Nymark

Musik is a responsive music theme with two widget areas and support for custom header and logo.

== Description ==
Musik is a responsive music theme with two widget areas and support for custom header and logo.
You can combine pages and posts on your front page, and change the position of your sidebar.
You can also change the width of your site or show your blog posts in a 3 column grid.
The different sections of the site have different opacities, allowing your background image to shine through.

Please note:
The header image is not shown on archives, pages or single posts, or when the sidebar is hidden.

== Upgrade Notice ==
For child theme authors: 
Please note that the markup for the main navigation and the header image has been changed in 1.9.
The code for the header image has also been moved from index.php to header.php.
The default background image size and file size has been drastically reduced,
the original image is in the images folder, called mic-original.
If you are experiencing problems with the background image, 
try removing the image in the customizer and then re-adding the default image.


== Changelog ==

Version: 2.3 2019-07-14
Updated text strings to make translation easier; some strings were duplicated.

Version: 2.2 2019-05-09
Added support for wp_body_open.
Added a block style for the gallery which hides the image captions.

Version: 2.1 2019-02-12
Added the flex height parameter to the custom logo option so that the logo can be shown in any size again.
Added the accessibility-ready and block-styles tags to style.css.
The header images have been further compressed to reduce the size.

Version: 2.0 2019-02-05
Made sure that the social menu, if used, shows next to the main menu by default.
Made sure that the page footer is only used if there is actual footer content such as footer widgets and footer credit text.
Removed a redundant headline from the author archive.
A minor style change for the "Read more" link, moving it to new line.
Accessibility improvements: Added underlines to links in the widget areas.
	Changed the text color and background image of the comments to increase the contrast.
Added a new screenshot to reflect the changes of the widget areas.


Version: 1.9 2019-01-08
Updated readme.txt file. Updated outdated links. Improved documentation.
Reduced background image size.
Fixed a problem with the select list text color.
Updated navigation.js so that jQuery is no longer needed.
Moved WooCommerce styles to a separate file and made sure the file only loads if WooCommerce is active.
Added support for header video (requires WordPress 4.7 or later).
Added a social menu, and options to select where to display it.
Added a skip link focus fix for IE11.
Added rtl styles.
Improved comment area styles for smaller screens.
Added styles and fonts for the block editor so that the editor better matches the front.
Updated author.php using get_the_author_meta.
Style changes to better comply with accessibility requirements:
Added underline to content links. Increased color contrast, some font sizes and line heights.
Reduced the number of colors used. 
Made sure that there is one H1 heading on all pages, and that heading levels are not skipped.

Version: 1.8 2017-12-14
Removed the customizer reset.
Removed the post background color meta box. -This is in preperation for Gutenberg where you are able to select background colors freely.
Removed the logo position options. -If you wish to display your logo in more than one position I recommend the image widget.

Moved the pingback url from header.php to a new function in functions.php.
Removed esc_html() from the widget descriptions.
The content width global has been moved to the musik_setup function and function musik_content_width has been removed.
wp_enqueue_script( 'comment-reply' ); is no longer wrapped in if ( ! is_admin() ).
The 3 dots in function musik_excerpt_more has been changed to a proper &hellip;.
Function musik_body_class, function musik_author, function musik_meta has been moved from customizer.php to functions.php.
Changed the default width to 80, down from 100.
Changed the default position of the background image.

Fixed an issue with a missing singular placeholder in comments.php.
Fixed minor code style issues (missing spaces and similar).
General cleanup of the stylesheet. 
	Minor style changes for buttons.
	Removed duplicate styles.
	Increased the minimum font size to 16px.
Added support for WooCommerce. 
Improved support for Jetpack.
Improved support for selective refresh.
Added starter content.

Version: 1.7 2016-07-10
Added Normalize to the stylesheet.
Removed Genericons.
Removed the breadcrumbs.
Removed the featured image size limitation.
Replaced the logo functionality with the WordPress core custom logo.
Made sure that the sidebars are not printed if they don't contain any widgets.
Made sure that the menu area is empty if no menu is selected. Updated the menu code.
Replaced header- post- and footer divs with their html5 equivalent.
Added micro data.
Updated the theme tags.
Customizer changes:
Added a reset option.
Added an option to adjust the site width.
Added an option to show the posts on the front page as a 3 column grid.
Added an option to show excerpts on blog listing, archives and search.
Moved the meta and breadcrumbs option to a new section called "Post settings".
Added an option to combine pages with your blog listing on the front page:
	You can now choose up to 3 pages that are shown above your blog posts.
Added an option to use an accent color to highlight individual posts. -The color is used on the front page, archives, and search.

Version: 1.6 2015-12-25
Fixed an issue with the header text color.

Version: 1.5 2015-12-17
Improved menu and navigation.
Improved accessibility.
Reduced image sizes and added several music related images that can be used as headers or bakgrounds.
Added a Bredcrumbs customizer section. This option was previously under the old navigation section.

Version: 1.4
Fixed bug with sidebar id's
Added add_theme_support( "title-tag" );
Removed register style

Version: 1.3
Fixed html and css errors.
Added skip link.

Version 1.1
Updated menu and related javascript
Updated background settings
Adjusted the way footer widgets and featured images are displayed 

== Credits ==

This theme is based on:
Underscores https://underscores.me/, (C) 2012-2019 Automattic, Inc. License: GNU General Public License v2 or later.
Twenty Seventeen (C) WordPress.org 2017-2019, License: GNU General Public License v2 or later.
Twenty Nineteen (C) WordPress.org 2018-2019, License: GNU General Public License v2 or later.
Universal, (C) Joe Dolson. License: GPLv2 or later.

Sanitization, (C) 2015-2019, WordPress Theme Review Team, GNU General Public License v2 or later.
https://github.com/WPTRT/code-examples/blob/master/customizer/sanitization-callbacks.php 

Folders included in this theme:
images/ -contains images.
inc/ -contains the customizer file.
templates/ -contains template files.
js/ -contains javascript files.

All included images are public domain.
The gradients, the guitar headers and the blue and purple microphone photo are taken by the theme author.

The other included photos are taken by Antoine Beauvillain:
https://stock.tookapic.com/photos/22792 Antoine Beauvillain
https://stock.tookapic.com/photos/25215 Antoine Beauvillain
(Yes I am aware that Tookapic has since changed their license. 
The images where added to the theme long before the license change, 
and you cannot revoke public domain.)

Fonts
Open Sans Condensed is released under Apache License, version 2.0.
Oswald is released under SIL Open Font License, version 1.1.
