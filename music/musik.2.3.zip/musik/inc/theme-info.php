<?php
/**
 * Documentation for Musik WordPress theme.
 *
 * @package Musik
 */

/**
 * Add the menu item under Appearance, themes.
 */
function musik_docs_menu() {
	add_theme_page(
		__( 'Musik Setup Help', 'musik' ),
		__( 'Musik Setup Help', 'musik' ),
		'edit_theme_options',
		'musik-theme',
		'musik_docs'
	);
}
add_action( 'admin_menu', 'musik_docs_menu' );

/**
 * Create the doucmentation page.
 */
function musik_docs() {
	?>
	<div class="wrap">
	<div class="welcome-panel">
	<div class="welcome-panel-content">
	<h1><?php esc_html_e( 'Musik Setup Help', 'musik' ); ?></h1>
	<br>
	<p class="about-description">
	<?php
	esc_html_e( 'Thank you for downloading and trying out Musik.', 'musik' );
	echo '<br>';
	printf(
		/* translators: %s: A link to the themes support page on WordPress.org  */
		__( 'If you like the theme, please review it on <a href="%s">WordPress.org</a>', 'musik' ),
		esc_url( 'https://wordpress.org/support/view/theme-reviews/musik' )
	);
	?>
	</p><br>

	<div class="welcome-panel-column-container">
	<div>
	<h2><?php esc_html_e( 'Personalize your theme:', 'musik' ); ?></h2>
	<a class="button button-primary button-hero load-customize"
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=custom_logo' ) ); ?>">
	<?php esc_html_e( 'Add a logo', 'musik' ); ?></a>
	<a class="button button-primary button-hero load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_top_section1' ) ); ?>">
	<?php esc_html_e( 'Enable frontpage sections', 'musik' ); ?></a>
	<a class="button button-primary button-hero load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_excerpt' ) ); ?>">
	<?php esc_html_e( 'Change post settings', 'musik' ); ?></a>
	<a class="button button-primary button-hero load-customize"
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_sidebar_left' ) ); ?>">
	<?php esc_html_e( 'Change sidebar position', 'musik' ); ?></a>
	<a class="button button-medium button-hero load-customize" 
	href="<?php echo esc_url( '#support' ); ?>">
	<?php esc_html_e( 'Ask for Support', 'musik' ); ?>
	</a>
	<br><br>
	</div>
	</div>
	</div>
	</div>

	<div class="welcome-panel">
	<div class="welcome-panel-content">
	<h2><?php esc_html_e( 'Upgrade notice', 'musik' ); ?></h2>

	<?php
	esc_html_e( 'In version 2.1, an additional parameter was added to the logo option. You can now freely choose your logo size again, both the height and width are flexible.', 'musik' );
	echo '<br>';
	esc_html_e( 'If you are updating to version 2.1 and are experiencing problems with the logo, remove the image and add it again.', 'musik' );
	echo '<br><br>';
	esc_html_e( 'In version 1.9, the background image size and file size has been reduced, to make the theme load faster.', 'musik' );
	echo '<br>';
	esc_html_e( 'If you are updating to version 1.9 and are experiencing problems with the background image, remove the image and add it again.', 'musik' );
	?>
	<br>
	<a class="button button-medium load-customize"
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=background_image' ) ); ?>">
	<?php esc_html_e( 'Change background', 'musik' ); ?></a>
	<br><br>    
	</div>
	</div>

	<div class="welcome-panel">
	<div class="welcome-panel-content">
	<h2><?php esc_html_e( 'Theme Documentation & Setup', 'musik' ); ?></h2>
	<nav>
		<ul class="subsubsub">
			<li><a href="#header"><?php esc_html_e( 'Header', 'musik' ); ?></a></li>
			<li><a href="#menus"><?php esc_html_e( 'Menus', 'musik' ); ?></a></li>
			<li><a href="#widgets"><?php esc_html_e( 'Widgets', 'musik' ); ?></a></li>
			<li><a href="#frontpage"><?php esc_html_e( 'Frontpage', 'musik' ); ?></a></li>
			<li><a href="#blog"><?php esc_html_e( 'Blog, Archve and Search', 'musik' ); ?></a></li>
			<li><a href="#footer"><?php esc_html_e( 'Footer', 'musik' ); ?></a></li>
		</ul>
	</nav>
	<br>
	<h3 id="header"><?php esc_html_e( 'Header', 'musik' ); ?></h3>
	<?php esc_html_e( 'Musik has several options where you can customize your header.', 'musik' ); ?>
	<br>
	<?php
	if ( version_compare( $GLOBALS['wp_version'], '4.7', '<' ) ) {
		esc_html_e( 'Note: Header video is only avialable from WordPress version 4.7.', 'musik' );
		echo '<br>';
	}
	esc_html_e( 'The header image or header video is optional. If you want to use a header image or video, the recommended size is 1100 x 300 pixels.', 'musik' );
	?>
	<br><a class="button button-medium load-customize"
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=header_image' ) ); ?>">
	<?php esc_html_e( 'Add a header image or video', 'musik' ); ?></a>
	<br><br>
	<?php esc_html_e( 'The logo is shown at the top of the page, to the left of your Site title. The recommended size for the logo is 60 x 60 pixels.', 'musik' ); ?>
	<br>
	<a class="button button-medium load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=custom_logo' ) ); ?>">
	<?php esc_html_e( 'Add a logo', 'musik' ); ?></a>
	<br><br>
	<?php esc_html_e( 'You can strengthen your branding further by adding a Site icon (favicon).', 'musik' ); ?>
	<br>
	<a class="button button-medium load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=site_icon' ) ); ?>">
	<?php esc_html_e( 'Add a site icon', 'musik' ); ?></a>
	<br>
	<h3 id="menus"><?php esc_html_e( 'Menus', 'musik' ); ?></h3>
	<?php esc_html_e( 'The theme has two menu locations: The Header Navigation and the Social Menu.', 'musik' ); ?>
	<div class="welcome-icon welcome-widgets-menus" style="margin:6px 0;">
	<a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>">
	<?php esc_html_e( 'Manage menus', 'musik' ); ?></a>
	</div>
	<h4 style="margin-bottom:6px;"><?php esc_html_e( '-How to add a social menu:', 'musik' ); ?></h4>
	<?php esc_html_e( 'The social menu uses svg icons to represent the social media links.', 'musik' ); ?>
	<?php echo esc_html_x( 'It does not display any text, but has additional information for screen readers.', 'the social menu', 'musik' ); ?><br>
	<?php esc_html_e( 'The icons will be added automatically, all you need to do is add a link to your menu.', 'musik' ); ?>
	<br>
	<?php esc_html_e( 'Create a new menu, then click on Custom links and add your URL.', 'musik' ); ?>
	<br>
	<?php esc_html_e( 'The Link Text that you provide is used as screen reader text.', 'musik' ); ?><br>
	<img style="margin:6px 0;" src="<?php echo esc_url( get_template_directory_uri() . '/images/doc-social2.jpg' ); ?>" 
		alt="<?php esc_attr_e( 'A form to add custom links to menus. The form has two fields, one for URL and one for Link Text.', 'musik' ); ?>"><br>
	<?php esc_html_e( 'Choose the theme location named Social Menu, and save.', 'musik' ); ?><br>
	<img style="margin:6px 0;" src="<?php echo esc_url( get_template_directory_uri() . '/images/doc-social3.jpg' ); ?>" 
		alt="<?php esc_attr_e( 'The Menu Settings form includes three checkboxes. Select the checkbox for the menu position that you prefer, and save the menu.', 'musik' ); ?>">
	<br>
	<?php esc_html_e( 'Troubleshooting: If your link or icon is not showing up, try using lower case letters.', 'musik' ); ?><br>
	<b><?php esc_html_e( 'Available icons:', 'musik' ); ?></b><br>
	<i style="display:block; max-width:340px;">
	<?php esc_html_e( 'amazon, bandcamp, behance, deviantart, codepen, digg, dribbble, dropbox, facebook, flickr, foursquare, ghost, github, google plus, instagram, linkedin, mixcloud, medium, pinterest, pocket, reddit, skype, slack, slideshare, spotify, soundcloud, stumbleupon, tumblr, twitch, twitter, wordpress, yelp, vimeo, vine, vk, youtube ', 'musik' ); ?>
	</i>
	<br>
	<?php esc_html_e( 'You can select between three different menu positions:', 'musik' ); ?>
	<ul>
		<li> <?php esc_html_e( 'To the right of the main menu', 'musik' ); ?></li>
		<li> <?php esc_html_e( 'At the bottom of the sidebar', 'musik' ); ?></li>
		<li> <?php esc_html_e( 'In the footer', 'musik' ); ?></li>
	</ul>
	<a class="button button-medium load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_social_menu_position' ) ); ?>">
	<?php esc_html_e( 'Select menu position', 'musik' ); ?></a>
	<br>
	<h3 id="widgets"><?php esc_html_e( 'Widgets', 'musik' ); ?></h3>
	<?php esc_html_e( 'The theme has two widget areas: A sidebar and a footer widget area. Both widget areas have room for any number of widgets.', 'musik' ); ?>
	<div class="welcome-icon welcome-widgets-menus">
		<a href="<?php echo esc_url( admin_url( 'widgets.php' ) ); ?>"><?php esc_html_e( 'Add widgets', 'musik' ); ?></a>
	</div>
	<?php esc_html_e( 'The sidebar can be placed either to the right or left of the content.', 'musik' ); ?>
	<br>
	<a class="button button-medium load-customize"
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_sidebar_left' ) ); ?>">
	<?php esc_html_e( 'Change sidebar position', 'musik' ); ?></a>
	<h3 id="frontpage"><?php esc_html_e( 'Frontpage', 'musik' ); ?></h3>
	<?php esc_html_e( 'Wether you want to show blog posts or a static page, you can combine this with three page sections that are only visible on the frontpage.', 'musik' ); ?>
	<br>
	<a class="button button-medium load-customize"
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_top_section1' ) ); ?>">
	<?php esc_html_e( 'Enable the frontpage sections', 'musik' ); ?></a>
	<h3 id="blog"><?php esc_html_e( 'Blog, Archve and Search', 'musik' ); ?></h3>
	<?php esc_html_e( 'By default, the full content of the posts are shown on the blog. If you prefer, you can choose to only show the excerpt.', 'musik' ); ?>
	<br>
	<a class="button button-medium load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_excerpt' ) ); ?>">
	<?php esc_html_e( 'Display excerpts', 'musik' ); ?></a>
	<br><br>
	<?php esc_html_e( 'You can also display the posts in a three column grid. Because of the limited space, this works best if you are showing excerpts.', 'musik' ); ?>
	<br>
	<a class="button button-medium load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_grid' ) ); ?>">
	<?php esc_html_e( 'Change post columns', 'musik' ); ?></a>
	<br><br>
	<?php esc_html_e( 'In the customizer you can also choose to hide the post meta information such as categories and tags.', 'musik' ); ?></a>
	<br>
	<a class="button button-medium load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=hide_authorinfo' ) ); ?>">
	<?php esc_html_e( 'Hide the "About the Author" section from the single post view', 'musik' ); ?></a>
	<br><br>
	<a class="button button-medium load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_hide_meta' ) ); ?>">
	<?php esc_html_e( 'Hide all the meta information', 'musik' ); ?></a>
	<br>
	<h3 id="footer"><?php esc_html_e( 'Footer', 'musik' ); ?></h3>
	<?php esc_html_e( 'Under the Site Identity panel in the customizer, there is also an option to display the site title and tagline in the footer.', 'musik' ); ?>
	<br>
	<a class="button button-medium load-customize" 
	href="<?php echo esc_url( admin_url( 'customize.php?autofocus[control]=musik_footer_title' ) ); ?>">
	<?php esc_html_e( 'Add the site title and tagline to the footer', 'musik' ); ?></a>
	<br><br>
	</div>
	</div>

	<div class="welcome-panel">
	<div class="welcome-panel-content" id="support">
	<h2><?php esc_html_e( 'Support', 'musik' ); ?></h2>
	<br><?php esc_html_e( 'Do you have questions, or is something not working as expected?', 'musik' ); ?>
	<br><?php esc_html_e( 'Or perhaps something is missing from the documentation?', 'musik' ); ?>
	<br>
	<?php
	printf(
		/* translators: %s: A link to the themes support page on WordPress.org  */
		__( 'Please visit the <a href="%s">official support forum</a>.', 'musik' ),
		esc_url( 'https://wordpress.org/support/theme/musik' )
	);
	echo '<br>';
	printf(
		/* translators: %s: A link to the theme authors email */
		__( '<a href="%s">You can also email me to check my availability</a> and I will reply as soon as I can.', 'musik' ),
		esc_url( 'mailto:carolina@theme.tips' )
	);
	?>
	<br><br>
	</div>
	</div>
	<?php
}
